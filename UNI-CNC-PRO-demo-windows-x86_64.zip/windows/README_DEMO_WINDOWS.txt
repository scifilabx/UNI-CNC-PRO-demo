================================================================
 UNI-CNC PRO — DEMO VERSION (Windows)
================================================================

This is a DEMO version: the editor accepts at most 100 lines of code.

To unlock the full version (no limit):
    1. Run the program and read your machine identifier from the
       header: "HWID: ...".
    2. Send this HWID to the vendor.
    3. You will receive a key. Save it to `license.key`
       (next to `unicnc_demo.exe`).
    4. Run the program again — the limit disappears (header shows
       "LICENCJA OK").

Requirements
------------
- Windows 10 / 11 (64-bit). No additional libraries needed —
  the .exe is self-contained.

Run
---
    1. Copy the whole `windows\` folder to your machine.
    2. Open `windows\` and run `unicnc_demo.exe`.

Example programs (ready to load)
--------------------------------
    przyklady\demo_walek_frezowany.nc   - milled shaft fi50 (holes on circumference)
    przyklady\demo_kostka_kieszen.nc    - milled block 100x70x20 with pocket

    Open them from FILE menu (F1 -> FILE -> choose file).

Contents
--------
  unicnc_demo.exe  - demo binary
  assets\          - configuration
  przyklady\       - example test programs
================================================================================
