================================================================
 UNI-CNC PRO — WERSJA DEMO (Linux / X11)
================================================================

To jest wersja DEMO z ograniczeniem: edytor przyjmuje maksymalnie
100 linii kodu.

Aby odblokować pełną wersję (bez limitu):
    1. Uruchom program i odczytaj z nagłówka swój identyfikator
       maszyny "HWID: ...".
    2. Prześlij ten HWID dostawcy.
    3. Otrzymasz klucz. Zapisz go w pliku `license.key`
       (obok pliku `unicnc_demo`).
    4. Uruchom program ponownie — limit zniknie (nagłówek pokaże
       "LICENCJA OK").

Wymagania systemowe (biblioteki współdzielone)
-----------------------------------------------
  sudo apt install -y libsdl2-2.0-0 libtbb12 libgl1 ocl-icd-libopencl1

Uruchomienie
------------
    cd linux
    ./unicnc_demo

Przykładowe programy (gotowe do wczytania)
-----------------------------------------
    przyklady/demo_walek_frezowany.nc   - frezowany wałek fi50 (otwory na obwodzie)
    przyklady/demo_kostka_kieszen.nc    - frezowana kostka 100x70x20 z kieszenią

    Otwórz je z menu PLIK (F1 -> PLIK -> wybierz plik).

Zawartość
---------
  unicnc_demo    - binarka (demo)
  assets/        - konfiguracja
  przyklady/     - przykładowe programy testowe
================================================================================
